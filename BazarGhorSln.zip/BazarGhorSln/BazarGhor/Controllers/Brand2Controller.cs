﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BazarGhor.Models;
using BazarGhor.Repositorise;
using Microsoft.AspNetCore.Mvc;

namespace BazarGhor.Controllers
{
    public class Brand2Controller : Controller
    {
        private readonly IBrandRepository brandRepository;

        public Brand2Controller(IBrandRepository brandRepository)
        {
            this.brandRepository = brandRepository;
        }
        public IActionResult BrandIndex2()
        {
            var model = brandRepository.GetallBrands().ToList();
            return View(model);
        }
        public IActionResult CreateBrand()
        {
            return View();
        }
        [HttpPost]
        public IActionResult CreateBrand(Brand pt)
        {
            if (ModelState.IsValid)
            {
                brandRepository.addBrand(pt);
                return RedirectToAction("BrandIndex2");
            }


            return View();
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var model = brandRepository.GetBrandById(id);
            Brand upPrdt = new Brand();
            upPrdt.BrandId = model.BrandId;
            return View(model);
        }
        [HttpPost]
        public IActionResult Edit(Brand typModel)
        {
            if (ModelState.IsValid)
            {

                Brand ob = brandRepository.GetBrandById(typModel.BrandId);

                ob.ProductBrandName = typModel.ProductBrandName;


                brandRepository.UpdateBrand(ob);
                return RedirectToAction("BrandIndex2");
            }

            return View();
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var model = brandRepository.GetBrandById(id);

            return View(model);
        }
        [HttpPost]
        [ActionName("Delete")]
        public IActionResult ConfimDelete(int id)
        {
            var model = brandRepository.GetBrandById(id);

            return RedirectToAction("TypeIndex");
        }
    }
}
