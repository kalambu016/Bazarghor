﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using BazarGhor.DAL;
using BazarGhor.Models;
using BazarGhor.Repositorise;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.CodeAnalysis;

namespace BazarGhor.Controllers
{
    public class BrandController : Controller
    {
        //private readonly IBrandRepository brandRepository;
        private readonly AppDataContext db;

        public BrandController( AppDataContext db)
        {
            //this.brandRepository = brandRepository;
            this.db = db;


        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetAllBrand()
        {
            var listOfBrand = db.Brands.ToList();
            return Json(listOfBrand, new Newtonsoft.Json.JsonSerializerSettings());

        }
        [HttpPost]
        public JsonResult Create([FromBody] Brand brand)
        {

            var b = db.Brands.Add(brand);
            db.SaveChanges();
            return Json(b, new Newtonsoft.Json.JsonSerializerSettings());
        }
        [HttpPost]
        public JsonResult UpdateBrand([FromBody] Brand brand)
        {

            var b = db.Brands.Find(brand.BrandId);
            if (b != null)
            {
                b.ProductBrandName = brand.ProductBrandName;
            }
            db.Brands.Update(b);
            db.SaveChanges();
            return Json(brand, new Newtonsoft.Json.JsonSerializerSettings());
        }

        public JsonResult Details(Brand br, int id)
        {
            var b = db.Brands.Where(p => p.BrandId == id).FirstOrDefault();
            return Json(b, new Newtonsoft.Json.JsonSerializerSettings());
        }
        [HttpPost]
        public JsonResult Delete( [FromBody]int id)
        {

            var b = db.Brands.Find(id);
            if (b != null)
            {
                db.Brands.Remove(b);
                db.SaveChanges();
            }

            return Json(b, new Newtonsoft.Json.JsonSerializerSettings());
        }


    }
}
