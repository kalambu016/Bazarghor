﻿using BazarGhor.DAL;
using BazarGhor.Models;
using BazarGhor.Repositorise;
using BazarGhor.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace BazarGhor.Controllers
{
    [Authorize]
    public class ProductController: Controller
    {
        private readonly IProductRepository productRepository;
        private readonly IHostingEnvironment hostingEnvironment;
        private readonly IProductTypeRepository productTypeRepository;
        private readonly IBrandRepository brandRepository;
        private readonly AppDataContext db;

        public ProductController(IProductRepository productRepository,IHostingEnvironment hostingEnvironment,
            IProductTypeRepository productTypeRepository, IBrandRepository brandRepository, AppDataContext db)
        {
            this.productRepository = productRepository;
            this.hostingEnvironment = hostingEnvironment;
            this.productTypeRepository = productTypeRepository;
            this.brandRepository = brandRepository;
            this.db = db;



        }
        [AllowAnonymous]
        [HttpGet]
        public IActionResult Index(string sortOrder, string currentFilter
            , string searchString, int? pageNumber)
        {
            ViewData["CurrentSort"] = sortOrder;
            ViewData["NameSortParam"] = String.IsNullOrEmpty(sortOrder)? "name_asc":"";
            if (searchString != null)
            {
                pageNumber = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewData["currentFilter"] = searchString;
            var model = productRepository.GetallProducts();
            var page = from p in model select p;
            if (!String.IsNullOrEmpty(searchString)) 
            {
                page = page.Where(p => p.ProductName.StartsWith(searchString));
            }
            switch (sortOrder)
            {
                case "name_asc":
                    page = (page.OrderBy(p => p.ProductName));
                    break;
                default:
                    page = (page.OrderByDescending(p => p.ProductName));
                    break;
            }
            
            ListofType();
            ListOfBrand();
            int pageSize = 8;
            return View(
                PaginatedList<Product>.Create(page.AsQueryable<Product>(), pageNumber ?? 1, pageSize));


        }

        [HttpGet]
        public IActionResult Create()
        {
            ListofType();
            ListOfBrand();
            return View();

        }
        [HttpPost]
        public ActionResult Create(CreateProductViewModel model)
        {
            if (ModelState.IsValid)
            {
                string uniqueFilename = processUploadFile(model);
               
                var data = new Product()
                {
                    ProductName = model.ProductName,
                    Quantity=model.Quantity,
                    Price = model.Price,
                    ProductDescriptin=model.ProductDescriptin,
                    IsAvailable=model.IsAvailable,
                    ProductTypeId = model.ProductTypeId,
                    BrandId=model.BrandId,
                    Image = uniqueFilename
                };
                productRepository.AddProduct(data);
                return RedirectToAction("Index");
            }
            ListOfBrand();
            ListofType();
            return View();
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var model = productRepository.GetProductByIyId(id);
            EditProductViewModel upPrdt = new EditProductViewModel();
            upPrdt.ProductId = model.ProductId;
            upPrdt.ProductName = model.ProductName;
            upPrdt.Quantity = model.Quantity;
            upPrdt.Price = model.Price;
            upPrdt.ProductDescriptin = model.ProductDescriptin;
            upPrdt.ProductTypeId = model.ProductTypeId;
            upPrdt.BrandId = model.BrandId;
            upPrdt.ExistFile = model.Image;
            ListOfBrand();
            ListofType();
            return View(upPrdt);
        }
        [HttpPost]
        public IActionResult Edit(EditProductViewModel proModel)
        {
            if (ModelState.IsValid)
            {

                Product ob = productRepository.GetProductByIyId(proModel.ProductId);

                ob.ProductName = proModel.ProductName;
                ob.Quantity = proModel.Quantity;
                ob.Price = proModel.Price;
                ob.ProductDescriptin = proModel.ProductDescriptin;
                ob.ProductTypeId = proModel.ProductTypeId;
                ob.BrandId = proModel.BrandId;
                if (proModel.Photo != null)
                {
                    if (proModel.ExistFile != null)
                    {
                        string filepath = Path.Combine(hostingEnvironment.WebRootPath, "images", proModel.ExistFile);
                        System.IO.File.Delete(filepath);
                    }
                    ob.Image = processUploadFile(proModel);
                }


                productRepository.UpdateProduct(ob);
                return RedirectToAction("Index");
            }
            ListOfBrand();
            ListofType();
            return View();
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var model = productRepository.GetProductByIyId(id);
            ListOfBrand();
            ListofType();
            return View(model);
        }
        [HttpPost]
        [ActionName("Delete")]
        public IActionResult ConfimDelete(int id)
        {
            var model = productRepository.DeleteProduct(id);
            ListOfBrand();
            ListofType();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Details(int id)
        {
            var model = productRepository.GetProductByIyId(id);
            ListOfBrand();
            ListofType();
            return View(model);
        }
        public IActionResult ForAdminView()
        {

            var model = productRepository.GetallProducts();
            ListOfBrand();
            ListofType();
            return View(model);
        }


        public void ListOfBrand(object getBarnd = null)
        {
            ViewBag.ListOfBrands = new SelectList(brandRepository.GetallBrands().ToList(), "BrandId", "ProductBrandName", getBarnd);
        }
        public void ListofType(object getType = null)
        {
            ViewBag.ListOfProductType = new SelectList(productTypeRepository.GetallProductType(), "ProductTypeId", "ProductTypeName", getType);

        }

        private string processUploadFile(CreateProductViewModel model)
        {
            string uniqueFilename = null;
            if (model.Photo != null)
            {
                string uploadFile = Path.Combine(hostingEnvironment.WebRootPath, "images");
                uniqueFilename = Guid.NewGuid().ToString() + "_" + model.Photo.FileName;
                string filePath = Path.Combine(uploadFile, uniqueFilename);
                model.Photo.CopyTo(new FileStream(filePath, FileMode.Create));
            }

            return uniqueFilename;
        }

    }
}
