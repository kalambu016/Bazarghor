﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BazarGhor.Models;
using BazarGhor.Repositorise;
using BazarGhor.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace BazarGhor.Controllers
{
    public class HomeController : Controller
    {
        private readonly IProductRepository productRepository;
        private readonly IProductTypeRepository productTypeRepository;
        private readonly IBrandRepository brandRepository;

        public HomeController(IProductRepository productRepository,
            IProductTypeRepository productTypeRepository, IBrandRepository brandRepository)
        {
            this.productRepository = productRepository;
            this.productTypeRepository = productTypeRepository;
            this.brandRepository = brandRepository;
        }
        [AllowAnonymous]
        public IActionResult Index(string sortOrder, string currentFilter
            , string searchString, int? pageNumber)
        {
           
            ViewData["CurrentSort"] = sortOrder;
            ViewData["NameSortParam"] = String.IsNullOrEmpty(sortOrder) ? "name_asc" : "";
            if (searchString != null)
            {
                pageNumber = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewData["currentFilter"] = searchString;
            var model = productRepository.GetallProducts();
           
            if (!String.IsNullOrEmpty(searchString))
            {
                model = model.Where(p => p.ProductName.StartsWith(searchString));
            }
            switch (sortOrder)
            {
                case "name_asc":
                    model = (model.OrderBy(p => p.ProductName));
                    break;
                default:
                    model = (model.OrderByDescending(p => p.ProductName));
                    break;
            }
            ViewData["PriceSortParam"] = String.IsNullOrEmpty(sortOrder) ? "price_asc" : "";
            switch (sortOrder)
            {
                case "price_asc":
                    model = (model.OrderByDescending(p => p.Price));
                    break;
                default:
                    model = (model.OrderBy(p => p.Price));
                    break;
            }
           
            ListofType();
            ListOfBrand();

            return View(model);
                


        }

        public void ListOfBrand(object getBarnd = null)
        {
            ViewBag.ListOfBrands = new SelectList(brandRepository.GetallBrands().ToList(), "BrandId", "ProductBrandName", getBarnd);
        }
        public void ListofType(object getType = null)
        {
            ViewBag.ListOfProductType = new SelectList(productTypeRepository.GetallProductType(), "ProductTypeId", "ProductTypeName", getType);

        }
    }
}
