﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BazarGhor.Models;
using BazarGhor.Repositorise;
using Microsoft.AspNetCore.Mvc;

namespace BazarGhor.Controllers
{
    public class TypeController : Controller
    {
        private readonly IProductTypeRepository productTypeRepository;

        public TypeController(IProductTypeRepository productTypeRepository)
        {
            this.productTypeRepository = productTypeRepository;
        }
        public IActionResult TypeIndex()
        {
            var model = productTypeRepository.GetallProductType().ToList();
            return View(model);
        }
        public IActionResult CreateType()
        {
            return View();
        }
        [HttpPost]
        public IActionResult CreateType(ProductType pt)
        {
            if (ModelState.IsValid)
            {
                productTypeRepository.AddProductType(pt);
                return RedirectToAction("TypeIndex");
            }
          
           
            return View();
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var model = productTypeRepository.GetProductByIdType(id);
            ProductType upPrdt = new ProductType();
            upPrdt.ProductTypeId = model.ProductTypeId;
            return View(model);
        }
        [HttpPost]
        public IActionResult Edit(ProductType typModel)
        {
            if (ModelState.IsValid)
            {

                ProductType ob = productTypeRepository.GetProductByIdType(typModel.ProductTypeId);

                ob.ProductTypeName = typModel.ProductTypeName;


                productTypeRepository.UpdateProductType(ob);
                return RedirectToAction("TypeIndex");
            }
           
            return View();
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var model = productTypeRepository.GetProductByIdType(id);
          
            return View(model);
        }
        [HttpPost]
        [ActionName("Delete")]
        public IActionResult ConfimDelete(int id)
        {
           var model= productTypeRepository.GetProductByIdType(id);
          
            return RedirectToAction("TypeIndex");
        }
    }
}
