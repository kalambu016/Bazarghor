﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BazarGhor.DAL;
using BazarGhor.Models;
using BazarGhor.Repositorise;
using BazarGhor.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace BazarGhor.Controllers
{
    public class CartController : Controller
    {
        private AppDataContext db;
        private readonly IProductRepository productRepository;
        private readonly IProductTypeRepository productTypeRepository;
        private readonly IBrandRepository brandRepository;
        public CartController(AppDataContext db, IProductRepository productRepository,
            IProductTypeRepository productTypeRepository, IBrandRepository brandRepository)
        {
            this.productRepository = productRepository;
            this.productTypeRepository = productTypeRepository;
            this.brandRepository = brandRepository;
            this.db = db;
        }
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Details(int id)
        {
            var model = db.Products.FirstOrDefault(p => p.ProductId == id);
            ListOfBrand();
            ListofType();
            return View(model);
        }



        [HttpPost]
        [ActionName("Details")]
        public IActionResult DetailsforAddSeason(int id)
        {
            List<Product> products = new List<Product>();
            var model = db.Products.FirstOrDefault(p=>p.ProductId==id);
            if (model != null)
            {
                products = HttpContext.Session.Get<List<Product>>("products");
                if (products == null)
                {
                    products = new List<Product>();
                }
                products.Add(model);
                HttpContext.Session.Set("products", products);
            }
            return View(model);
        }
        [HttpPost]
        public IActionResult RemoveCart(int id)
        {
            List<Product> products = HttpContext.Session.Get<List<Product>>("products");
            if (products != null)
            {
                var product = products.FirstOrDefault(p => p.ProductId == id);
                if (product != null)
                {
                    products.Remove(product);
                    HttpContext.Session.Set("products", products);
                }
            }

            return RedirectToAction("ListOfProduct", "Home");
        }
        [HttpGet]
        public IActionResult Cart()
        {
            List<Product> products = HttpContext.Session.Get<List<Product>>("products");
            if (products == null)
            {
                products = new List<Product>();
            }
            return View(products);
        }
        public void ListOfBrand(object getBarnd = null)
        {
            ViewBag.ListOfBrands = new SelectList(brandRepository.GetallBrands().ToList(), "BrandId", "ProductBrandName", getBarnd);
        }
        public void ListofType(object getType = null)
        {
            ViewBag.ListOfProductType = new SelectList(productTypeRepository.GetallProductType(), "ProductTypeId", "ProductTypeName", getType);

        }
    }
}
