﻿using BazarGhor.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BazarGhor.ViewModels
{
    public class CreateProductViewModel
    {
        public int ProductItemId { get; set; }
        [Required(ErrorMessage = "product name is Required")]
        [Display(Name = "Product Name")]
        public string ProductName { get; set; }
        [Required(ErrorMessage = "Quantity must be added")]
        public string Quantity { get; set; }

        [Required(ErrorMessage = "product price is reqired")]
        public decimal Price { get; set; }
        [StringLength(400, ErrorMessage = "Not more than 400 characters", MinimumLength = 5)]
        [Display(Name = "Description")]
        public string ProductDescriptin { get; set; }
        public string Image { get; set; }
        [Display(Name = "Available")]
        public bool IsAvailable { get; set; }
        [Display(Name = "Product Type")]
        public int ProductTypeId { get; set; }

        public ProductType ProductTypes { get; set; }
        [Display(Name = "Bran Name")]
        public int BrandId { get; set; }

        public Brand Brands { get; set; }
        public IFormFile Photo { get; set; }


    }
}
