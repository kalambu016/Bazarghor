﻿function confirmDeletemethod(uniqueId, idDeletedClicked) {
    var DeleteSpan = "DeleteSpan_" + uniqueId;
    var confirmDelete = "confirmDelete_" + uniqueId;
    if (idDeletedClicked) {
        $('#' + DeleteSpan).hide();
        $('#' + confirmDelete).show();
    }
    else {
        $('#' + DeleteSpan).show();
        $('#' + confirmDelete).hide();
    }
}