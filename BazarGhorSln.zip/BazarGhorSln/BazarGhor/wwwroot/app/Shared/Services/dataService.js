﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('dataServ8sice', ["$http", "$q", function ($http, $q) {

            var service = {};
            service.getBrand = function () {
                var deferred = $q.defer();
                $http.get("/Brand/GetAllBrand").then(function (result) {
                    deferred.resolve(result.data);
                }, function () {
                    deferred.reject();
                });
                return deferred.promise;
            };

          
            service.getBrandById = function (id) {
                var deferred = $q.defer();
                $http.get("/Brand/Details/" + id).then(function (result) {
                    deferred.resolve(result.data);
                }, function () {
                    deferred.reject();
                });
                return deferred.promise;
            };


            service.addBrand = function (brand) {
                var deferred = $q.defer();
                $http.post('/Brand/Create', brand).then(function () {
                    deferred.resolve();
                }, function () {
                    deferred.reject();
                });
                return deferred.promise;
            };

            service.EditBrand = function (brand) {
                var deferred = $q.defer();
                $http.post('/Brand/UpdateBrand', brand).then(function () {
                    deferred.resolve();
                }, function () {
                        deferred.reject();
                });
                return deferred.promise;
            };

            return service;
        }])

})();