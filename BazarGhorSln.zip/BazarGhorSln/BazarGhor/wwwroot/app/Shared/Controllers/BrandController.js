﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('BrandController', ['$scope', 'dataService', function ($scope, dataService) {

            $scope.brands = [];
            getData();
            function getData() {
                dataService.getBrand().then(function (result) {
                    $scope.brands = result;
                });
            }
            $scope.removeBrand = function (id) {
                dataService.deleteBrand(id).then(function () {
                    alert("Data list id"  +  id)
                    getData();
                }, function () {

                        alert("error to delete" + id)
                });
            }

        }])
        .controller('brandAddController', ['$scope', '$location', 'dataService', function ($scope, $location, dataService) {

            $scope.CreateBrand = function (brand) {
                dataService.addBrand(brand).then(function () {
                    $location.path('/')
                }, function () {

                        alert("Error Is creating")
                })
            }
        }])
        .controller('EditBrnController', ['$scope', '$routeParams', '$location', 'dataService', function ($scope, $routeParams, $location, dataService) {

            $scope.brand = {};
            dataService.getBrandById($routeParams.id).then(function (result) {
                $scope.brand = result;
            }, function () {
                alert("Error Is creating")
            });
            $scope.editbandMethod = function (brand) {
                dataService.EditBrand(brand).then(function () {
                    $location.path('/')
                }, function () {
                    alert("error occured...")
                })
            }

        }])

  
})();
