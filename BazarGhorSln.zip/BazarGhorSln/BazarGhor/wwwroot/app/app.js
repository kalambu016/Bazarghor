﻿(function () {
    'use strict';

    angular
        .module('app', [

            'ngRoute'

        ])
        .config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
            $locationProvider.hashPrefix('');
            $routeProvider
                .when('/', {
                    controller: 'BrandController',
                    templateUrl: '/app/Shared/Templates/Brands.html'
                })
                .when('/addBrand', {
                    controller: 'brandAddController',
                    templateUrl: '/app/Shared/Templates/CreateBrand.html'
                })
                .when('/EditBrand/:id', {
                    controller: 'EditBrnController',
                    templateUrl: '/app/Shared/Templates/EditBrand.html'
                })
                .when('/deleteBrand/:id', {
                    controller: 'DeleteBrnController',
                    templateUrl: '/app/Shared/Templates/deleteBrand.html'
                })
                .otherwise({ redirectTo: '/' });
        }]);
})();