﻿using BazarGhor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BazarGhor.Repositorise
{
    public interface IBrandRepository
    {
        IEnumerable<Brand> GetallBrands();
        Brand addBrand(Brand B);
        Brand UpdateBrand(Brand ChangeBrand);
        Brand deleteBrand(int id);
        Brand GetBrandById(int id);
       
        
    }
}
