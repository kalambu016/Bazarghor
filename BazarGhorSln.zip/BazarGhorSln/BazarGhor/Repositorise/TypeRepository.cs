﻿using BazarGhor.DAL;
using BazarGhor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BazarGhor.Repositorise
{
    public class TypeRepository : IProductTypeRepository
    {
        private readonly AppDataContext context;

        public TypeRepository(AppDataContext context)
        {
            this.context = context;
        }
        public ProductType AddProductType(ProductType p)
        {
            context.ProductTypes.Add(p);
            context.SaveChanges();
            return p;
        }

        public ProductType DeleteProductType(int id)
        {
            var model = context.ProductTypes.FirstOrDefault(p => p.ProductTypeId == id);
            if (model != null)
            {
                context.Remove(model);
                context.SaveChanges();
            }
         
            return model;
        }

        public IEnumerable<ProductType> GetallProductType()
        {
            return context.ProductTypes.ToList();
        }

        public ProductType GetProductByIdType(int id)
        {
            var model = context.ProductTypes.FirstOrDefault(p => p.ProductTypeId == id);
            return model;

        }

        public ProductType UpdateProductType(ProductType ChangeType)
        {
            var model = context.ProductTypes.Attach(ChangeType);
            model.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            context.SaveChanges();
            return ChangeType;
        }
    }
}
