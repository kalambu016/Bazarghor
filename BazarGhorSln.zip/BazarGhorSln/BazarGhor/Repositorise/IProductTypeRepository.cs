﻿using BazarGhor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BazarGhor.Repositorise
{
    public interface IProductTypeRepository
    {
        IEnumerable<ProductType> GetallProductType();
        ProductType AddProductType(ProductType p);
        ProductType UpdateProductType(ProductType ChangeType);
        ProductType DeleteProductType(int id);
        ProductType GetProductByIdType(int id);
    }
}
