﻿using BazarGhor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BazarGhor.Repositorise
{
   public interface IProductRepository
    {
        IEnumerable<Product> GetallProducts();
        Product AddProduct(Product p);
        Product UpdateProduct(Product ChangeProduct);
        Product DeleteProduct(int id);
        Product GetProductByIyId(int id);
     


    }
}
