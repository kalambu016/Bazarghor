﻿using BazarGhor.DAL;
using BazarGhor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace BazarGhor.Repositorise
{
    public class BrandRepository : IBrandRepository
    {
     
        private readonly AppDataContext context;

        public BrandRepository(AppDataContext context)
        {
            this.context = context;
        }
        public Brand addBrand(Brand B)
        {
            context.Brands.Add(B);
            context.SaveChanges();
            return B;

        }

        public Brand deleteBrand(int id)
        {
            var model = GetBrandById(id);
                context.Brands.Remove(model);
                context.SaveChanges();
            return model;
        }

        public IEnumerable<Brand> GetallBrands()
        {

            return context.Brands.ToList();
        }

        public Brand GetBrandById(int id)
        {

            return context.Brands.Find(id);
        }

        public Brand UpdateBrand(Brand ChangeBrand)
        {


            var model = context.Brands.Attach(ChangeBrand);
            model.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            context.SaveChanges();
            return ChangeBrand;

        }

    }
}
