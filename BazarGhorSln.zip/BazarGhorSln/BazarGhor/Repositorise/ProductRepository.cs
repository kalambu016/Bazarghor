﻿using BazarGhor.DAL;
using BazarGhor.Models;
using Microsoft.EntityFrameworkCore;
using ReflectionIT.Mvc.Paging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BazarGhor.Repositorise
{
    public class ProductRepository : IProductRepository
    {
        private readonly AppDataContext context;

        public ProductRepository(AppDataContext context)
        {
            this.context = context;
        }

        public Product AddProduct(Product p)
        {
            context.Products.Add(p);
            context.SaveChanges();
            return p;
        }

        public Product DeleteProduct(int id)
        {
            var model = GetProductByIyId(id);
            if (model != null)
            {
                context.Products.Remove(model);
                context.SaveChanges();
            }
            return model;
        }

        public IEnumerable<Product> GetallProducts()
        {
            var data = context.Products.ToList();


            return data;
           
        }

        public Product GetProductByIyId(int id)
        {
            var model = context.Products.FirstOrDefault(p => p.ProductId == id);
            return model;
        }

        public Product UpdateProduct(Product ChangeProduct)
        {
            var model = context.Products.Attach(ChangeProduct);
            model.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            context.SaveChanges();
            return ChangeProduct;
        }

 
    }
}
