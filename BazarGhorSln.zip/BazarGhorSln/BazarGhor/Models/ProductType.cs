﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BazarGhor.Models
{
    public class ProductType
    {
        public int ProductTypeId { get; set; }
        [Required(ErrorMessage = "Product type not added yet")]
        [Display(Name = "Product Type")]
        public string ProductTypeName { get; set; }
        public virtual ICollection<Product> Products { get; set; }
    }
}
