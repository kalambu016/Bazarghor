﻿using BazarGhor.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BazarGhor.DAL
{
    public class AppDataContext: IdentityDbContext
    {
   

        public AppDataContext(DbContextOptions<AppDataContext> options)
            :base(options)
        {
                
        }
        public DbSet<ProductType> ProductTypes { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Brand> Brands { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
           
            modelBuilder.Entity<Product>().HasKey(s => s.ProductId);
            modelBuilder.Entity<ProductType>().HasKey(s => s.ProductTypeId);
            modelBuilder.Entity<Brand>().HasKey(s => s.BrandId);
            modelBuilder.Entity<Product>().HasOne(s => s.Brands).WithMany(s => s.Products)
           .HasForeignKey(s => s.BrandId).OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Product>().HasOne(s => s.ProductTypes).WithMany(s => s.Products)
                .HasForeignKey(s => s.ProductTypeId).OnDelete(DeleteBehavior.Restrict);

        }
    }
}
